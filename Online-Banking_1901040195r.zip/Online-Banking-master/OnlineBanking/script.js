document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " StateBankOfIndia. All rights reserved.</p>";
